import sys
from PySide6.QtCore import QSize, Qt
from PySide6.QtWidgets import *
# from design import Ui_Dialog
from test_design import Ui_MainWindow 

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        self.ui.pushButton.clicked.connect(self.addRow)

        self.ui.tableWidget.setColumnWidth(1, 10)



    def addRow(self):
        self.currentRowCount = self.ui.tableWidget.rowCount() # c
        self.ui.tableWidget.insertRow(self.currentRowCount)

app=QApplication(sys.argv)
window=MainWindow()
window.showMaximized()
window.show()
app.exec()